KALEIDOSCOPE
Indiecade Submission Build May.31.2013 

Diego Garcia, Toni Pizza, & Aaron Freedman

---ABOUT----------------------------------
You are the captain of an ill-fated space vessel. Your crew is stranded throughout the cosmos, alone and helpless. Help them out of their loneliness by gathering them and allowing them to perish with their comrades.

You'll move to a new sector once you save all your crew in the current sector.

--CONTROLS--------------------------------
Left/Right : Rotate or Walk on planet
Space : On planet: hold to charge jump; release to jump. In space: jet-pack
s : suicide
Insert (Print Screen) : take screenshot

--NOTE------------------------------------
Kaleidoscope doesn't save your progress. You'll have to complete your game in one sitting.